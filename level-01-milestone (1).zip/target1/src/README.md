## Milestone 1
Use the following command to run
```shell
ruby cli.rb
```
Write your code inside application.rb